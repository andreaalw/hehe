package SL04;

import java.util.ArrayList;
import java.util.Scanner;

public class Siswa extends Person{

    ArrayList<Siswa> sis = new ArrayList<>();
    Scanner scanner = new Scanner(System.in);
    String NISN;


    public Siswa() {

    }

//    public Siswa(String name, String Matkul, String pass,String NISN){
//        super(name,Matkul,pass);
//        this.NISN = NISN;
//    }

//    public static void login() {
//       String name, Pass;
//        Scanner scanner1= new Scanner(System.in);
//        System.out.println("Input Your Name: ");
//        name = scanner1.nextLine();
//
//        System.out.println("input your Password");
//        Pass = scanner1.nextLine();
//
//    }

//    @Override
//    public void login(Scanner scan) {
//        login(scan);
////        String name, Pass;
////        System.out.println("Input your Name: ");
////        name = scan.nextLine();
////
////        System.out.println("Input yor password: ");
////        Pass = scan.nextLine();
//
//
//    }

//    @Override
//    public void login(Person name, Person Matkul, Person pass) {
////        name = scanner.nextLine();
//
//    }

//    @Override
    public void login(String nama, String nisn, String pass) {
        do {
            System.out.printf("1. input your name: ");
            this.name = scanner.nextLine();
            System.out.printf("2. input your NISN: ");
            this.NISN = scanner.nextLine();
            System.out.printf("2. input your password: ");
            this.pass = scanner.nextLine();
            sis.add(new Siswa(nama,nisn,pass));
        }while (!name.equalsIgnoreCase(nama) && !NISN.equalsIgnoreCase(nisn) && !this.pass.equalsIgnoreCase(pass));


    }

    public void display(){
        display();
    }

//    @Override
//    public void login(String name, String Pass) {
//        System.out.printf("input your Name: ");
//        name = scanner.nextLine();
//        System.out.printf("input your password");
//        pass = scanner.nextLine();
//
//
//    }

//    public static void main(String[] args) {
//    }
}
