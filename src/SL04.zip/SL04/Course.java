package SL04;

public class Course{
    double nilai;


}
