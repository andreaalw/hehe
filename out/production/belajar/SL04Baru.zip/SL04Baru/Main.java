package SL04Baru;

import SL04.Siswa;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Scanner sc1 = new Scanner(System.in);
        Course course = new Course(null,null);
        Score score = new Score(null,null,0);

        ArrayList<Score> scores = new ArrayList<>();

        ArrayList<Student> students = new ArrayList<>();
        ArrayList<Teacher> teachers = new ArrayList<>();

//         Student student = new Student("Andrea","12344","akumurid");
//         Student student1 = new Student("Raymond", "44567","akumurid");

//         Teacher teacher = new Teacher("Theokleia","9090","akuguru");
//         Teacher teacher1 = new Teacher("Appolonia","1823","akuguru");




        int role,menu,menu1=0;

        do{
            System.out.println("Welcome to wakanda primary School");
            System.out.println("Choose Your role");
            System.out.println("1. Student");
            System.out.println("2. Teacher");
            System.out.println("3. Logout");
            System.out.print(">>");
            role = sc.nextInt();


            if(role == 1){
                String name1 = Student.name;
                String pass1 = Student.pass;
//                String name, pass;
                System.out.println("Hi student!!");
                System.out.printf("1. Input Your name: ");
                name1= sc.next();

                boolean check = true; //variable check

                do {
                    System.out.printf("2. Input Your Pass: ");
                    pass1 = sc.next();

                    if(Student.checkPass(pass1)){
                        do{
                            System.out.println("Helllo student Of Wakanda School");
                            System.out.println("1. Pilih pelajaran");
                            System.out.println("2. Lihat nilai");
                            System.out.println("3. Back");

                            menu = sc.nextInt();

                            switch (menu){
                                case 1:
                                    score.input(sc);
                                    break;
                                case 2:
                                    score.viewBener();
//                                    int i = 1;
//                                    for (Score scoree : scores) {
//                                        System.out.println(i+". Your Course is "+scoree.getMapel()+" Type"+ score.getTipe()+" Your Score is "+scoree.getUjian());
//                                        i++;
//                                    }
                                    break;
                                case 3:
                                    break;
                            }

                        }while(menu!=3);

                        check = true;

                    }else {
                        check = false;
                    }
                }while (!check);


                students.add(new Student(name1, pass1));




            }else if(role == 2) {


                String name = Teacher.name;
                String pass = Teacher.pass;
                System.out.println("Hi Teacher!!");
                System.out.printf("1. Input Your name: ");
                name = sc.next();

                boolean check2 = true;

                do {

                    System.out.printf("2. input Your password: ");
                    pass = sc.next();

                    if (Teacher.checkPass(pass)) {

                        do {

                            System.out.println("Hello Wakanda Teacher!!");
                            System.out.println("1. Input Nilai");
                            System.out.println("2. Back");
                            System.out.printf(">>");
                            menu1 = sc.nextInt();

                            switch (menu1) {
                                case 1:
                                    score.input(sc);
                                    break;
                                case 2:
//                            default:
                                    break;
                            }


                        } while (menu1 != 3);
                    } else {
                        check2 = false;
                    }
                }while (!check2);
            }
            else{
                System.out.println("you have logged out...");
                System.out.println("thank you for using this application!");
            }

        }while (role!=3);
    }
}
