package SL04Baru;

import java.util.ArrayList;
import java.util.Scanner;

public class Score extends Course{

    int Ujian;

    public int getUjian() {
        return Ujian;
    }

    Score(String mapel, String tipe, int Ujian){
        super(mapel, tipe);
        this.Ujian = Ujian;
    }
    ArrayList<Score> scores = new ArrayList<>();
    void addCourse(){
        scores.add(new Score("Matematika",tipe,Ujian));
        scores.add(new Score("Indonesia",tipe,Ujian));
        scores.add(new Score("IPA",tipe,Ujian));

    }

    @Override
    void input(Scanner sc){
        String  choose;



      Course course = new Course(mapel,tipe);
      course.view();
        System.out.println("Please choose your course: ");
        mapel = sc.next();
        System.out.println("Choose mau nilai yang mana");
        System.out.println("1. Exam ");
        System.out.println("2. Task");
        choose = sc.next(); // ujian //tugas
        if(choose.equalsIgnoreCase("Exam")){
            System.out.printf("Iput Exam score: ");
            Ujian = sc.nextInt();
        } else if (choose.equalsIgnoreCase("Task")) { //
            System.out.printf("Input Task Score: ");
            Ujian = sc.nextInt();
        }

        System.out.println("apakah mau input nilai lagi[Y/N]: ");
        String pilih = sc.next();
        if (pilih.equalsIgnoreCase("Y")){
            input(sc);
        }else {
            scores.add(new Score(mapel,choose,Ujian));
        }




    }

   public void viewBener() {
        int i =1;
        for (Score score : scores) {
            System.out.println(i+". Your Course is "+score.mapel+" Type"+ score.tipe+" Your Score is "+score.Ujian);
            i++;
        }

//       System.out.println(""+scores.get(""+scores.get(Integer.parseInt(mapel)));

    }


}
