package SL04Baru;

public class Mapel extends Course {

    public Mapel(String mapel, String tipe) {
        super(mapel, tipe);
    }

    void displayTu(){

    }

    void displayEx(){

    }



}
